<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Stylish Form Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    header {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      color: white;
      padding: 15px 0;
    }
    header h3 {
      font-weight: 600;
    }
    header a {
      color: white;
      text-decoration: none;
      margin: 0 12px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    header a:hover {
      color: #ffd700;
    }
    .form-container {
      background: white;
      border-radius: 20px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
      max-width: 600px;
      width: 100%;
      padding: 40px 35px;
      margin: 70px auto;
      transition: transform 0.3s;
    }
    .form-container:hover {
      transform: translateY(-5px);
    }
    .form-label {
      font-weight: 500;
      color: #444;
    }
    .btn-primary {
      background: linear-gradient(90deg, #6a11cb, #2575fc);
      border: none;
      border-radius: 25px;
      padding: 10px 25px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    .btn-primary:hover {
      background: linear-gradient(90deg, #2575fc, #6a11cb);
      transform: scale(1.05);
    }
    footer {
      margin-top: auto;
      background: rgba(0, 0, 0, 0.8);
      color: #fff;
      text-align: center;
      padding: 15px 0;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header>
    <div class="container d-flex justify-content-between align-items-center">
      <h3 class="m-0">O7 Services</h3>
      <nav>
        <a href="form.html">Form</a>
        <a href="table.html">View Table</a>
        <a href="#">About</a>
        <a href="#">Contact</a>
      </nav>
    </div>
  </header>

  <!-- Form Section -->
  <div class="form-container">
    <h4 class="text-center mb-4 text-primary">✨ Student Registration Form ✨</h4>
    <form>
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" class="form-control" placeholder="Enter your full name" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" class="form-control" placeholder="Enter your email" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Phone Number</label>
        <input type="tel" class="form-control" placeholder="Enter your contact number">
      </div>
      <div class="mb-3">
        <label class="form-label">Message</label>
        <textarea class="form-control" rows="3" placeholder="Write your message..."></textarea>
      </div>
      <div class="text-center">
        <button type="submit" class="btn btn-primary px-4">Submit</button>
      </div>
    </form>
  </div>

  <!-- Footer -->
  <footer>
    <p class="mb-0">&copy; 2025 O7 Services | Designed with ❤️ by Simran</p>
  </footer>

</body>
</html>
