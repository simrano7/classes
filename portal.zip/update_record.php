<?php
include("header.php");
include("db.php");

$message = "";

// Get record ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<div class='alert alert-danger text-center'>Invalid record ID.</div>");
}
$id = intval($_GET['id']);

// Fetch existing data
$stmt = $conn->prepare("SELECT * FROM records WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    die("<div class='alert alert-danger text-center'>Record not found.</div>");
}
$row = $result->fetch_assoc();

// Initialize variables with existing data
$category = $row['category'];
$title = $row['title'];
$details = $row['details'];
$year = $row['year'];
$addedBy = $row['addedby'];
$person_details = $row['persondetails'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = trim($_POST['category']);
    $title = trim($_POST['title']);
    $details = trim($_POST['details']);
    $year = trim($_POST['year']);
    $addedBy = trim($_POST['addedBy']);
    $person_details = trim($_POST['person_details']);

    // Validation
    if (empty($category) || empty($title) || empty($details) || empty($year) || empty($addedBy) || empty($person_details)) {
        $message = "<div class='alert alert-danger text-center'>⚠️ All fields are required.</div>";
    } elseif (!preg_match('/^[0-9]{4}$/', $year)) {
        $message = "<div class='alert alert-warning text-center'>Enter a valid year (e.g., 2025).</div>";
    } else {
        // Update statement
        $stmt = $conn->prepare("UPDATE records SET category=?, title=?, details=?, year=?, persondetails=?, addedby=? WHERE id=?");
        $stmt->bind_param("ssssssi", $category, $title, $details, $year, $person_details, $addedBy, $id);

        if ($stmt->execute()) {
            $message = "<div class='alert alert-success text-center'>🎉 Record updated successfully!</div>";
            echo "<script>
            setTimeout(()=>{
                window.location.assign('showdetails.php');        
            },2000)
            
            </script>";
        } else {
            $message = "<div class='alert alert-danger text-center'>❌ Error updating record: ".$stmt->error."</div>";
        }

        $stmt->close();
    }
}
?>

<!-- Form Section -->
<div class="form-container">
  <form method="POST" class="needs-validation" novalidate>
    <h2>Update Record</h2>

    <?php echo $message; ?>

    <label for="category">Category</label>
    <select id="category" name="category" required>
      <option value="" disabled <?php echo empty($category) ? 'selected' : ''; ?>>-- Select Type --</option>
      <option value="Workshop" <?php echo ($category=='Workshop')?'selected':''; ?>>Workshop</option>
      <option value="Seminar" <?php echo ($category=='Seminar')?'selected':''; ?>>Seminar</option>
      <option value="Placement Drive" <?php echo ($category=='Placement Drive')?'selected':''; ?>>Placement Drive</option>
      <option value="Diwali Gift" <?php echo ($category=='Diwali Gift')?'selected':''; ?>>Diwali Gift</option>
    </select>

    <label for="title">Title</label>
    <input type="text" id="title" name="title" placeholder="Enter title" required
           value="<?php echo htmlspecialchars($title); ?>" />

    <label for="details">Details</label>
    <textarea id="details" name="details" placeholder="Enter full details about the event..." required><?php echo htmlspecialchars($details); ?></textarea>

    <label for="year">Year</label>
    <input type="number" id="year" name="year" placeholder="Enter Year (e.g., 2025)" required
           value="<?php echo htmlspecialchars($year); ?>" />

    <label for="addedBy">Added By</label>
    <input type="text" id="addedBy" name="addedBy" placeholder="Enter your name" required
           value="<?php echo htmlspecialchars($addedBy); ?>" />

    <label for="person_details">Person Details</label>
    <textarea id="person_details" name="person_details" placeholder="Enter person details..." required><?php echo htmlspecialchars($person_details); ?></textarea>

    <button type="submit">Update Record</button>
  </form>
</div>

<?php
include("footer.php");
?>
