<?php
include("header.php");
include("db.php");

$message = "";

// Initialize variables to retain form values
$category = $title = $details = $year = $addedBy = $person_details = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = trim($_POST['category']);
    $title = trim($_POST['title']);
    $details = trim($_POST['details']);
    $year = trim($_POST['year']);
    $addedBy = trim($_POST['addedBy']);
    $person_details = trim($_POST['person_details']);

    // Validation
    if (empty($category) || empty($title) || empty($details) || empty($year) || empty($addedBy) || empty($person_details)) {
        $message = "<div class='alert alert-danger text-center'>⚠️ All fields are required.</div>";
    } elseif (!preg_match('/^[0-9]{4}$/', $year)) {
        $message = "<div class='alert alert-warning text-center'>Enter a valid year (e.g., 2025).</div>";
    } else {
        // Prepare statement
        $stmt = $conn->prepare("INSERT INTO records (category, title, details, year, persondetails, addedby) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("ssssss", $category, $title, $details, $year, $person_details, $addedBy);

        if ($stmt->execute()) {
            $message = "<div class='alert alert-success text-center'>🎉 Record added successfully!</div>";

            // Clear form fields after successful insert
            $category = $title = $details = $year = $addedBy = $person_details = "";
        } else {
            $message = "<div class='alert alert-danger text-center'>❌ Error saving record: ".$stmt->error."</div>";
        }

        $stmt->close();
    }
}
?>

<!-- Form Section -->
<div class="form-container">
  <form method="POST" class="needs-validation" novalidate>
    <h2> Add Record</h2>

    <?php echo $message; ?>
       <?php
// Fetch all unique categories from records table
$categories = [];
$result = $conn->query("SELECT DISTINCT category FROM records ORDER BY category ASC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category'];
    }
}
?>
<select id="category" name="category" required>
    <option value="" disabled <?php echo empty($category) ? 'selected' : ''; ?>>-- Select Type --</option>
    <?php foreach ($categories as $cat): ?>
        <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo ($category==$cat)?'selected':''; ?>>
            <?php echo htmlspecialchars($cat); ?>
        </option>
    <?php endforeach; ?>
    <option value="addMore">➕ Add More</option>
</select>


        <!-- <select id="category" name="category" required>
        <option value="" disabled <?php echo empty($category) ? 'selected' : ''; ?>>-- Select Type --</option>
        <option <?php echo ($category=='Workshop')?'selected':''; ?>>Workshop</option>
        <option <?php echo ($category=='Seminar')?'selected':''; ?>>Seminar</option>
        <option <?php echo ($category=='Placement Drive')?'selected':''; ?>>Placement Drive</option>
        <option <?php echo ($category=='Diwali Gift')?'selected':''; ?>>Diwali Gift</option>
        <option value="addMore">➕ Add More</option>
    </select> -->

    <label for="title">Title</label>
    <input type="text" id="title" name="title" placeholder="Enter title (e.g., Diwali Celebration 2025)" required
           value="<?php echo htmlspecialchars($title); ?>" />

    <label for="details">Details</label>
    <textarea id="details" name="details" placeholder="Enter full details about the event..." required><?php echo htmlspecialchars($details); ?></textarea>

    <label for="year">Year</label>
    <input type="number" id="year" name="year" placeholder="Enter Year (e.g., 2025)" required
           value="<?php echo htmlspecialchars($year); ?>" />

    <label for="addedBy">Added By</label>
    <input type="text" id="addedBy" name="addedBy" placeholder="Enter your name" required
           value="<?php echo htmlspecialchars($addedBy); ?>" />

    <label for="person_details">Person Details</label>
    <textarea id="person_details" name="person_details" placeholder="Enter person details..." required><?php echo htmlspecialchars($person_details); ?></textarea>

    <button type="submit">Add Record</button>
  </form>
</div>


<script>
document.getElementById('category').addEventListener('change', function() {
    if (this.value === 'addMore') {
        let newCategory = prompt("Enter new category:");
        if (newCategory) {
            // Create new option
            let option = document.createElement("option");
            option.text = newCategory;
            option.value = newCategory;
            // Add the new option before the "Add More" option
            let addMoreOption = this.querySelector('option[value="addMore"]');
            this.add(option, addMoreOption);
            // Select the newly added option
            this.value = newCategory;
        } else {
            // Reset to default if no value entered
            this.value = "";
        }
    }
});
</script>

<?php
include("footer.php");
?>
