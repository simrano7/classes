<?php
include("db.php");

$id = $_POST['id'] ?? '';
$category = trim($_POST['category'] ?? '');
$title = trim($_POST['title'] ?? '');
$details = trim($_POST['details'] ?? '');
$year = trim($_POST['year'] ?? '');
$addedby = trim($_POST['addedby'] ?? '');
$persondetails = trim($_POST['persondetails'] ?? '');

if (!$id || !$category || !$title || !$details || !$year || !$addedby || !$persondetails) {
    echo "<div class='alert alert-danger'>⚠️ All fields are required.</div>";
    exit;
}

if (!preg_match('/^[0-9]{4}$/', $year)) {
    echo "<div class='alert alert-warning'>Enter a valid year (e.g., 2025).</div>";
    exit;
}

$stmt = $conn->prepare("UPDATE records SET category=?, title=?, details=?, year=?, addedby=?, persondetails=? WHERE id=?");
$stmt->bind_param("ssssssi", $category, $title, $details, $year, $addedby, $persondetails, $id);

if ($stmt->execute()) {
    echo "<div class='alert alert-success'>✅ Record updated successfully!</div>";
} else {
    echo "<div class='alert alert-danger'>❌ Error updating record.</div>";
}
$stmt->close();
?>
