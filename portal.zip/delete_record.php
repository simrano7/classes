<?php

if(isset($_REQUEST['id']))
{
    $id = $_REQUEST['id'];
    include("db.php");
    $query = "DELETE FROM `records` WHERE `id`='$id'";
    $result = mysqli_query($conn,$query);
    if($result>0)
    {
        echo "<script>window.location.assign('showdetails.php?msg=Record Deleted')</script>";
    }
    else{
        echo "<script>window.location.assign('showdetails.php?msg=Try Again')</script>";
    }
}
?>