<?php
include("header.php");
include("db.php");
$limit = 10; // records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Filters
$filterCategory = $_GET['category'] ?? '';
$filterYear = $_GET['year'] ?? '';
$searchTerm = $_GET['search'] ?? '';

// Fetch all unique categories for filter dropdown
$categories = [];
$resultCat = $conn->query("SELECT DISTINCT category FROM records ORDER BY category ASC");
if ($resultCat) {
    while ($row = $resultCat->fetch_assoc()) {
        $categories[] = $row['category'];
    }
}

// Build WHERE clause dynamically
$where = " WHERE 1=1 ";
if(!empty($filterCategory)) {
    $where .= " AND category = '" . $conn->real_escape_string($filterCategory) . "'";
}
if(!empty($filterYear)) {
    $where .= " AND year = '" . $conn->real_escape_string($filterYear) . "'";
}
if(!empty($searchTerm)) {
    $searchTerm = $conn->real_escape_string($searchTerm);
    $where .= " AND (title LIKE '%$searchTerm%' OR details LIKE '%$searchTerm%' OR addedby LIKE '%$searchTerm%' OR persondetails LIKE '%$searchTerm%' OR category LIKE '%$searchTerm%' OR year LIKE '%$searchTerm%')";
}

// Get total records for pagination
$totalResult = $conn->query("SELECT COUNT(*) AS total FROM records $where");
$totalRow = $totalResult->fetch_assoc();
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $limit);

// Get current page data
$sql = "SELECT * FROM records $where ORDER BY id DESC LIMIT $start, $limit";
$result = $conn->query($sql);


?>

<section class="content-section container">
    <h2 class="text-center ">📋 Records</h2>

    <!-- Category Cards -->
   

    <!-- Filter Form -->
<!-- Floating Filter Button -->
<div class="filter-toggle" id="filterToggle">
  <i class="fa fa-filter"></i>
</div>

<!-- Hidden Slide Filter Panel -->
<div class="filter-panel" id="filterPanel">
<form method="GET">
  <span id="closeFilter" style="position:absolute;top:15px;right:15px;font-size:22px;cursor:pointer;">&times;</span>

  <h4>Filters</h4>
  <select name="category" class="filter-input">
                <option value="">All Categories</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?= htmlspecialchars( $cat) ?>" <?= ($filterCategory == $cat) ? 'selected' :''?>>
                        <?= htmlspecialchars($cat) ?>
                    </option>
                <?php endforeach; ?>
            </select>
  <!-- <select name="category" class="filter-input">
    <option value="">-- Select Category --</option>
    <option value="Workshop" <?= isset($_GET['category']) && $_GET['category'] == 'Workshop' ? 'selected' : '' ?>>Workshop</option>
    <option value="Seminar" <?= isset($_GET['category']) && $_GET['category'] == 'Seminar' ? 'selected' : '' ?>>Seminar</option>
    <option value="Diwali Gifts" <?= isset($_GET['category']) && $_GET['category'] == 'Diwali Gifts' ? 'selected' : '' ?>>Diwali Gifts</option>
  </select> -->

  <input type="text" name="year" placeholder="Enter Year" value="<?= isset($_GET['year']) ? $_GET['year'] : '' ?>" class="filter-input" />
  <input type="text" name="search" placeholder="Search..." value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>" class="filter-input" />

  <button type="submit" class="filter-btn">Apply</button>
</form>


</div>

    <!-- Records Table: Visible on desktop -->
    <div class="table-responsive d-none d-md-block">
        <table class="table table-bordered table-hover">
            <thead class="table-primary" >
                <tr>
                    <th>Srno</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th>Details</th>
                    <th>Year</th>
                    <th>Added By</th>
                    <th>Person Details</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($result->num_rows > 0): ?>
                    <?php
                        $sno=1;
                        $result->data_seek(0);
                        while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $sno; ?></td>
                            <td><?php echo $row['category']; ?></td>
                            <td><?php echo $row['title']; ?></td>
                            <!-- <td><?php echo $row['details']; ?></td> -->
                            <td>
                                <?php 
                                $shortDetails = strlen($row['details']) > 50 ? substr($row['details'],0,50)."..." : $row['details'];
                                echo htmlspecialchars($shortDetails);
                                ?>
                                <?php if(strlen($row['details']) > 50): ?>
                                    <!-- <a href="view_record.php?id=<?php echo $row['id']; ?>" class=" ms-2">more...</a> -->
                                      <a class="view-btn" 
                                data-id="<?php echo $row['id']; ?>" 
                                data-title="<?php echo htmlspecialchars($row['title']); ?>"
                                data-category="<?php echo htmlspecialchars($row['category']); ?>"
                                data-details="<?php echo htmlspecialchars($row['details']); ?>"
                                data-year="<?php echo htmlspecialchars($row['year']); ?>"
                                data-addedby="<?php echo htmlspecialchars($row['addedby']); ?>"
                                data-person="<?php echo htmlspecialchars($row['persondetails']); ?>">
                                    more...
                                </a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $row['year']; ?></td>
                            <td><?php echo $row['addedby']; ?></td>
                            <td>
                            <?php 
                                $shortDetails = strlen($row['persondetails']) > 50 ? substr($row['persondetails'],0,50)."..." : $row['persondetails'];
                                echo htmlspecialchars($shortDetails);
                                ?>
                                <?php if(strlen($row['persondetails']) > 50): ?>
                                      <a class="view-btn" 
                                data-id="<?php echo $row['id']; ?>" 
                                data-title="<?php echo htmlspecialchars($row['title']); ?>"
                                data-category="<?php echo htmlspecialchars($row['category']); ?>"
                                data-details="<?php echo htmlspecialchars($row['details']); ?>"
                                data-year="<?php echo htmlspecialchars($row['year']); ?>"
                                data-addedby="<?php echo htmlspecialchars($row['addedby']); ?>"
                                data-person="<?php echo htmlspecialchars($row['persondetails']); ?>">
                                    more...
                                </a>
                                    <!-- <a href="view_record.php?id=<?php echo $row['id']; ?>" class=" ms-2">more...</a> -->
                                <?php endif; ?>
                        
                        </td> 
                        <td>
                            
                             <a class="edit-btn"
                                data-id="<?php echo $row['id']; ?>"
                                data-title="<?php echo htmlspecialchars($row['title']); ?>"
                                data-category="<?php echo htmlspecialchars($row['category']); ?>"
                                data-details="<?php echo htmlspecialchars($row['details']); ?>"
                                data-year="<?php echo htmlspecialchars($row['year']); ?>"
                                data-addedby="<?php echo htmlspecialchars($row['addedby']); ?>"
                                data-person="<?php echo htmlspecialchars($row['persondetails']); ?>">
                                <i class="fa-solid fa-pen-to-square pe-3"></i>
                              </a>
                            <a href="delete_record.php?id=<?php echo $row['id']?>"><i class="fa-solid fa-trash"></i></a>
                        </td>
                        </tr>
                    <?php 
                    $sno++;    
                endwhile;
                    ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center">No records found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
                <div class="text-end mb-3">
            <a href="download_csv.php?category=<?php echo urlencode($filterCategory); ?>&year=<?php echo urlencode($filterYear); ?>&search=<?php echo urlencode($searchTerm); ?>" 
            class="btn btn-success">
            <i class="fa-solid fa-download"></i> Download CSV
            </a>
        </div>

    </div>

    <!-- Records Cards: Visible only on mobile -->
    <div class="d-block d-md-none">
        <?php 
        // Fetch data again for cards
        if($result->num_rows > 0):
            $conn->query("SET @rownum := $start + 1"); // for proper numbering
            $result->data_seek(0); // rewind pointer

            $sno=1 + $start;
            while($row = $result->fetch_assoc()): ?>
            <div class="card mobile-record-card mb-3 shadow-sm p-3">
                <div class="row mb-2">
                    <div class="col-12"><span class="badge bg-primary">#<?php echo $sno; ?></span></div>
                </div>
                <div class="row mb-1"><div class="col-12"><strong>Category:</strong> <?php echo $row['category']; ?></div></div>
                <div class="row mb-1"><div class="col-12"><strong>Title:</strong> <?php echo $row['title']; ?></div></div>
                <div class="row mb-1"><div class="col-12"><strong>Details:</strong>
             <?php 
                    $shortDetails = strlen($row['details']) > 50 ? substr($row['details'],0,50)."..." : $row['details'];
                    echo htmlspecialchars($shortDetails);
                    ?>
                    <?php if(strlen($row['details']) > 50): ?>
                        <!-- <a href="view_record.php?id=<?php echo $row['id']; ?>" class=" ms-2">more...</a> -->
                          <a class="view-btn" 
                                data-id="<?php echo $row['id']; ?>" 
                                data-title="<?php echo htmlspecialchars($row['title']); ?>"
                                data-category="<?php echo htmlspecialchars($row['category']); ?>"
                                data-details="<?php echo htmlspecialchars($row['details']); ?>"
                                data-year="<?php echo htmlspecialchars($row['year']); ?>"
                                data-addedby="<?php echo htmlspecialchars($row['addedby']); ?>"
                                data-person="<?php echo htmlspecialchars($row['persondetails']); ?>">
                                    more...
                                </a>
                    <?php endif; ?>  
            </div>
        </div>
                <div class="row mb-1"><div class="col-12"><strong>Year:</strong> <?php echo $row['year']; ?></div></div>
                <div class="row mb-1"><div class="col-12"><strong>Added By:</strong> <?php echo $row['addedby']; ?></div></div>
                <div class="row mb-1"><div class="col-12"><strong>Person Details:</strong>
                
                  <?php 
                                $shortDetails = strlen($row['persondetails']) > 50 ? substr($row['persondetails'],0,50)."..." : $row['persondetails'];
                                echo htmlspecialchars($shortDetails);
                                ?>
                                <?php if(strlen($row['persondetails']) > 50): ?>
                                    <!-- <a href="view_record.php?id=<?php echo $row['id']; ?>" class=" ms-2">more...</a> -->
                                      <a class="view-btn" 
                                            data-id="<?php echo $row['id']; ?>" 
                                            data-title="<?php echo htmlspecialchars($row['title']); ?>"
                                            data-category="<?php echo htmlspecialchars($row['category']); ?>"
                                            data-details="<?php echo htmlspecialchars($row['details']); ?>"
                                            data-year="<?php echo htmlspecialchars($row['year']); ?>"
                                            data-addedby="<?php echo htmlspecialchars($row['addedby']); ?>"
                                            data-person="<?php echo htmlspecialchars($row['persondetails']); ?>">
                                                more...
                                            </a>
                                <?php endif; ?>
            
            </div>
            <div class="row">
                <div class="col-md-6">

                </div>
                <div class="col-md-6"></div>
                <a class="edit-btn"
                    data-id="<?php echo $row['id']; ?>"
                    data-title="<?php echo htmlspecialchars($row['title']); ?>"
                    data-category="<?php echo htmlspecialchars($row['category']); ?>"
                    data-details="<?php echo htmlspecialchars($row['details']); ?>"
                    data-year="<?php echo htmlspecialchars($row['year']); ?>"
                    data-addedby="<?php echo htmlspecialchars($row['addedby']); ?>"
                    data-person="<?php echo htmlspecialchars($row['persondetails']); ?>">
                    <i class="fa-solid fa-pen-to-square pe-3"></i>
</a>

               
                   <a href="delete_record.php?id=<?php echo $row['id']?>"><i class="fa-solid fa-trash"></i></a>
            </div>
        </div>
            </div>
        <?php 
            $sno++;
            endwhile;
        else: ?>
            <div class="card p-3 text-center mb-3 shadow-sm">No records found</div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <nav aria-label="Page navigation">
      <ul class="pagination justify-content-center">
        <?php for($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?php if($i==$page) echo 'active'; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>
                    <?php if($filterCategory) echo '&category='.$filterCategory; ?>
                    <?php if($filterYear) echo '&year='.$filterYear; ?>
                    <?php if($searchTerm) echo '&search='.$searchTerm; ?>">
                    <?php echo $i; ?>
                </a>
            </li>
        <?php endfor; ?>
      </ul>
    </nav>
    <!-- Modal Popup -->
<div id="detailsModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>

    <div class="modal-header">
      <h2 id="modalTitle"></h2>
    </div>
    
    <div class="modal-body">
        <p class="modal-category"><strong>Category:</strong> <span id="modalCategory"></span></p>
      <p><strong>Details:</strong></p>
      <p id="modalDetails"></p>

      <div class="modal-row">
        <p><strong>Year:</strong> <span id="modalYear"></span></p>
        <p><strong>Added By:</strong> <span id="modalAddedBy"></span></p>
      </div>

      <p><strong>Person Details:</strong></p>
      <p id="modalPerson"></p>
    </div>
  </div>
</div>
<!-- Update Modal -->
<div id="updateModal" class="modal" >
          <div class="modal-content1" className="mx-5" >
            <span class="close close-update">&times;</span>
            <div class="modal-header">
              <h2>✏️ Update Record</h2>
            </div>
            <div id="updateMessage" class="mt-3"></div>

            <!-- replaced: use a modal-form class (full width inside modal) -->
            <form id="updateForm" method="POST" class="modal-form" >
              <input type="hidden" name="id" id="updateId">

              <label>Category</label>
              <select name="category" id="updateCategory" required>
                <option value="">-- Select Type --</option>
                <option value="Workshop">Workshop</option>
                <option value="Seminar">Seminar</option>
                <option value="Placement Drive">Placement Drive</option>
                <option value="Diwali Gift">Diwali Gift</option>
              </select>

              <label>Title</label>
              <input type="text" name="title" id="updateTitle" required>

              <label>Details</label>
              <textarea name="details" id="updateDetails" required></textarea>

              <label>Year</label>
              <input type="number" name="year" id="updateYear" required>

              <label>Added By</label>
              <input type="text" name="addedby" id="updateAddedBy" required>

              <label>Person Details</label>
              <textarea name="persondetails" id="updatePerson" required></textarea>

              <button type="submit" class="btn btn-primary w-100 mt-3">Update Record</button>
            </form>
          </div>
        </div>


</section>

<style>
.table-responsive { overflow-x: auto; }
input, select { border-radius: 8px; }
.pagination .page-item.active .page-link {
    background-color: #0054D4;
    border-color: #0054D4;
}
.card { 
    transition: all 0.2s;
    cursor: pointer;
    border: 1px solid #ddd;
}
.card:hover {
    transform: scale(1.05);
    border-color: #0054D4;
}
.border-primary { border-color: #0054D4 !important; }

.mobile-record-card {
    border-radius: 12px;
    font-size: 1rem;
    border-left: 4px solid #0054D4;
    background: #f8f9fa;
}   
.mobile-record-card .badge {
    font-size: 1em;
}

.modal{
  display: none;
  position: fixed;
  z-index: 999;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow-y: auto;
  background-color: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(3px);
  padding: 20px;
}

/* Modal Box */
.modal-content {
  background: #ffffff;
  margin: 5% auto;
  padding: 25px;
  border-radius: 15px;
  width: 90%;
  max-width: 600px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  animation: slideDown 0.3s ease-in-out;
  position: relative;
}
.modal-content1 {
  background: #ffffff;
  margin: 5% auto;
  padding: 25px;
  border-radius: 15px;
  width: 90%;
  max-width: 600px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  animation: slideDown 0.3s ease-in-out;
  position: relative;
  /* align-items: center;/ */
}

/* Close Button */
.close {
  position: absolute;
  right: 15px;
  top: 10px;
  font-size: 26px;
  color: #333;
  cursor: pointer;
  transition: 0.3s;
}
.close:hover {
  color: red;
}

/* Modal Header */
.modal-header {
  border-bottom: 2px solid #eee;
  margin-bottom: 15px;
  padding-bottom: 10px;
}

.modal-header h2 {
  font-size: 1.6rem;
  color: #222;
  margin-bottom: 5px;
}

.modal-category {
  color: #666;
  font-size: 0.95rem;
}

/* Modal Body */
.modal-body {
  font-size: 1rem;
  color: #333;
  line-height: 1.6;
   text-align: justify;
}
.modal-body p {
  margin: 10px 0;
   text-align: justify;
}

/* Row styling for year & added by */
.modal-row {
  display: flex;
  justify-content: space-between; 
  flex-wrap: wrap;
  gap: 10px;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    padding: 20px;
  }
  .modal-header h2 {
    font-size: 1.3rem;
  }
  .modal-body {
    font-size: 0.95rem;
  }
}
@media (max-width: 480px) {
  .modal-content {
    margin-top: 20%;
  }
  .modal-row {
    flex-direction: column;
  }
  .modal-header h2 {
    font-size: 1.2rem;
  }
}
.btn-success {
  background: #16a34a;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 8px 16px;
  cursor: pointer;
  transition: 0.3s;
}
.btn-success:hover {
  background: #15803d;
}


/* Animation */
@keyframes slideDown {
  from { transform: translateY(-40px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

/* Button Style */
/* .view-btn {
  background: linear-gradient(135deg, #007bff, #0056b3);
  color: #fff;
  border: none;
  padding: 7px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.3s;
  font-size: 0.9rem;
}
.view-btn:hover {
  background: linear-gradient(135deg, #0056b3, #003e80);
} */
 
.modal-content1 {
  box-sizing: border-box; /* ensure padding doesn't blow out width */
}

/* make modal padding smaller on very small screens so form fits */
@media (max-width: 576px) {
  .modal-content1 { padding: 14px; max-width: 96%; }
  #updateForm label { font-weight: 600; margin-top: 8px; display:block; }
  #updateForm textarea { min-height: 120px; }
}

/* keep comfortable spacing on medium+ screens */
@media (min-width: 768px) {
  .modal-content1 { padding: 22px 28px; }
}
/* Compact Filter Section */
.filter-form {
  background: #f8f9fa;
  border-radius: 10px;
  padding: 10px 15px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.filter-form select,
.filter-form input {
  height: 38px;
  font-size: 0.9rem;
}

.filter-form button {
  height: 38px;
  font-size: 0.9rem;
}

/* Mobile view optimization */
@media (max-width: 768px) {
  .filter-form {
    margin: 10px auto;
    padding: 8px;
  }
  .filter-form .col-md-3 {
    flex: 0 0 50%;
    max-width: 50%;
    padding: 4px;
  }
  .filter-form button {
    width: 100%;
    font-size: 0.85rem;
  }
}

/* Floating Filter Icon Button */
.filter-toggle {
  position: fixed;
  top: 30%;
  right: 20px;
  background: #007bff;
  color: white;
  width: 45px;
  height: 45px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 999;
  box-shadow: 0 4px 10px rgba(0,0,0,0.2);
  transition: background 0.3s;
}
.filter-toggle:hover {
  background: #0056b3;
}

/* Slide Filter Panel */
.filter-panel {
  position: fixed;
  top: 0;
  right: -320px; /* hidden initially */
  width: 300px;
  height: 100%;
  background: #fff;
  box-shadow: -2px 0 8px rgba(0,0,0,0.1);
  padding: 25px 20px;
  transition: right 0.4s ease;
  z-index: 998;
  border-radius: 10px 0 0 10px;
}

/* Active state (visible) */
.filter-panel.active {
  right: 0;
}

/* Filter Form Elements */
.filter-panel h4 {
  text-align: center;
  margin-bottom: 20px;
  color: #333;
}

.filter-input {
  width: 100%;
  margin-bottom: 12px;
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #ccc;
  outline: none;
  font-size: 14px;
}

.filter-btn {
  width: 100%;
  background: #007bff;
  color: white;
  border: none;
  padding: 10px;
  border-radius: 8px;
  font-size: 15px;
  cursor: pointer;
  transition: background 0.3s;
}
.filter-btn:hover {
  background: #0056b3;
}

/* Responsive Fix */
@media (max-width: 768px) {
  .filter-panel {
    width: 80%;
  }
}

</style>
<script>
     document.addEventListener('DOMContentLoaded', function() {
     const modal = document.getElementById('detailsModal');
     const closeBtn = document.querySelector('.close');

    document.querySelectorAll('.view-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.getElementById('modalTitle').innerText = btn.dataset.title;
        document.getElementById('modalCategory').innerText = btn.dataset.category;
        document.getElementById('modalDetails').innerText = btn.dataset.details;
        document.getElementById('modalYear').innerText = btn.dataset.year;
        document.getElementById('modalAddedBy').innerText = btn.dataset.addedby;
        document.getElementById('modalPerson').innerText = btn.dataset.person;
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden'; // prevent background scroll
      });
    });

   closeBtn.onclick = function() {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
    }

    window.onclick = function(event) {
    if (event.target === modal) {
      modal.style.display = 'none';
      document.body.style.overflow = 'auto';
    }
  }
});
document.addEventListener('DOMContentLoaded', function () {
  const updateModal = document.getElementById('updateModal');
  const closeUpdate = document.querySelector('.close-update');
  const updateForm = document.getElementById('updateForm');
  const updateMsg = document.getElementById('updateMessage');

  // Open modal when Edit button clicked
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('updateId').value = btn.dataset.id;
      document.getElementById('updateCategory').value = btn.dataset.category;
      document.getElementById('updateTitle').value = btn.dataset.title;
      document.getElementById('updateDetails').value = btn.dataset.details;
      document.getElementById('updateYear').value = btn.dataset.year;
      document.getElementById('updateAddedBy').value = btn.dataset.addedby;
      document.getElementById('updatePerson').value = btn.dataset.person;

      updateModal.style.display = 'block';
      document.body.style.overflow = 'hidden';

    });
  });

  // Close modal
  closeUpdate.onclick = () => {
    updateModal.style.display = 'none';
    document.body.style.overflow = 'auto';
  };
  window.onclick = e => {
    if (e.target === updateModal) {
      updateModal.style.display = 'none';
      document.body.style.overflow = 'auto';
    }
  };

  // Handle form submission via AJAX
  updateForm.addEventListener('submit', async e => {
    e.preventDefault();

    const formData = new FormData(updateForm);

    const response = await fetch('update_record_ajax.php', {
      method: 'POST',
      body: formData
    });
    const result = await response.text();
    updateMsg.innerHTML = result;

    // Refresh page after success
    if (result.includes('successfully')) {
      setTimeout(() => location.reload(), 1500);
    }
  });
});
  const filterToggle = document.getElementById("filterToggle");
  const filterPanel = document.getElementById("filterPanel");

  filterToggle.addEventListener("click", () => {
    filterPanel.classList.toggle("active");
  });

  // Auto close panel after submit
  const filterForm = document.querySelector(".filter-panel form");
  filterForm.addEventListener("submit", () => {
    filterPanel.classList.remove("active");
  });

  // Toggle filter panel visibility
  filterToggle.addEventListener("click", () => {
    filterPanel.classList.toggle("active");
  });

  // Optional: close panel when user clicks outside of it
  document.addEventListener("click", (e) => {
    if (
      !filterPanel.contains(e.target) &&
      !filterToggle.contains(e.target)
    ) {
      filterPanel.classList.remove("active");
    }
  });
   const closeFilter = document.getElementById("closeFilter");

  filterToggle.addEventListener("click", () => {
    filterPanel.classList.toggle("active");
  });

  closeFilter.addEventListener("click", () => {
    filterPanel.classList.remove("active");
  });

  document.addEventListener("click", (e) => {
    if (
      !filterPanel.contains(e.target) &&
      !filterToggle.contains(e.target)
    ) {
      filterPanel.classList.remove("active");
    }
  });
</script>



<?php
include("footer.php");
?>
