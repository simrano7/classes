<?php
include("db.php");

// Get filters
$filterCategory = $_GET['category'] ?? '';
$filterYear = $_GET['year'] ?? '';
$searchTerm = $_GET['search'] ?? '';

// Base query
$where = " WHERE 1=1 ";
if(!empty($filterCategory) && $filterCategory != 'All') {
    $where .= " AND category = '" . $conn->real_escape_string($filterCategory) . "'";
}
if(!empty($filterYear)) {
    $where .= " AND year = '" . $conn->real_escape_string($filterYear) . "'";
}
if(!empty($searchTerm)) {
    $searchTerm = $conn->real_escape_string($searchTerm);
    $where .= " AND (title LIKE '%$searchTerm%' OR details LIKE '%$searchTerm%' OR addedby LIKE '%$searchTerm%' OR persondetails LIKE '%$searchTerm%' OR category LIKE '%$searchTerm%' OR year LIKE '%$searchTerm%')";
}

// Fetch filtered records
$sql = "SELECT * FROM records $where ORDER BY id DESC";
$result = $conn->query($sql);

// Set headers for download
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="filtered_records.csv"');

// Open output stream
$output = fopen('php://output', 'w');

// Add CSV headers
fputcsv($output, ['SrNo', 'Category', 'Title', 'Details', 'Year', 'Added By', 'Person Details']);

// Add rows
if ($result && $result->num_rows > 0) {
    $sno = 1;
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $sno++,
            $row['category'],
            $row['title'],
            $row['details'],
            $row['year'],
            $row['addedby'],
            $row['persondetails']
        ]);
    }
}

fclose($output);
exit;
?>
