<?php
include("header.php");
include("db.php");

$id = intval($_GET['id']);
$sql = "SELECT * FROM records WHERE id=$id";
$result = $conn->query($sql);
if($result->num_rows == 0){
    echo "<div class='container mt-5'>Record not found.</div>";
    exit;
}
$row = $result->fetch_assoc();
?>

<div class="container my-5">
    <h2 class="mb-3"><?php echo htmlspecialchars($row['title']); ?></h2>
    <p><strong>Category:</strong> <?php echo htmlspecialchars($row['category']); ?></p>
    <p><strong>Year:</strong> <?php echo htmlspecialchars($row['year']); ?></p>
    <p><strong>Added By:</strong> <?php echo htmlspecialchars($row['addedby']); ?></p>
    <p><strong>Person Details:</strong> <?php echo htmlspecialchars($row['persondetails']); ?></p>
    <p><strong>Details:</strong><br><?php echo nl2br(htmlspecialchars($row['details'])); ?></p>
    <a href="showdetails.php" class="btn btn-secondary mt-3">Back to Records</a>
</div>

<?php include("footer.php"); ?>
