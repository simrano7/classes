
  <!-- Footer -->
  <footer>
    © 2025 O7 Services | Designed❤️ by <a href="#">o7Services</a>
  </footer>

  <!-- Mobile Menu Script -->
  <script>
    function toggleMenu() {
      const menu = document.getElementById("menu");
      menu.classList.toggle("show");
    }
  </script>
   <script>
    // Mobile Menu Toggle
    function toggleMenu() {
      const menu = document.getElementById("menu");
      menu.classList.toggle("show");
    }

    // Search Filter Function
    function searchTable() {
      const input = document.getElementById("searchInput").value.toLowerCase();
      const rows = document.querySelectorAll("#studentTable tbody tr");

      rows.forEach(row => {
        const name = row.cells[1].textContent.toLowerCase();
        row.style.display = name.includes(input) ? "" : "none";
      });
    }
  </script>

    <!-- JS -->
  <script>
    // Mobile Menu Toggle
    function toggleMenu() {
      const menu = document.getElementById("menu");
      menu.classList.toggle("show");
    }

    // Search Filter Function
    function searchTable() {
      const input = document.getElementById("searchInput").value.toLowerCase();
      const rows = document.querySelectorAll("#studentTable tbody tr");

      rows.forEach(row => {
        const name = row.cells[1].textContent.toLowerCase();
        row.style.display = name.includes(input) ? "" : "none";
      });
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>
