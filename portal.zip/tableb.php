<?php
include("header.php");
include("db.php");

// Pagination settings
$limit = 10; // records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Filters
$filterCategory = $_GET['category'] ?? '';
$filterYear = $_GET['year'] ?? '';
$searchTerm = $_GET['search'] ?? '';

// Base query
$where = " WHERE 1=1 ";
if (!empty($filterCategory)) {
    $where .= " AND category = '" . $conn->real_escape_string($filterCategory) . "'";
}
if (!empty($filterYear)) {
    $where .= " AND year = '" . $conn->real_escape_string($filterYear) . "'";
}
if (!empty($searchTerm)) {
    $searchTerm = $conn->real_escape_string($searchTerm);
    $where .= " AND (title LIKE '%$searchTerm%' OR details LIKE '%$searchTerm%' OR addedby LIKE '%$searchTerm%' OR persondetails LIKE '%$searchTerm%')";
}

// Get total records for pagination
$totalResult = $conn->query("SELECT COUNT(*) AS total FROM records $where");
$totalRow = $totalResult->fetch_assoc();
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $limit);

// Get current page data
$sql = "SELECT * FROM records $where ORDER BY id DESC LIMIT $start, $limit";
$result = $conn->query($sql);
?>

<section class="content-section container">
    <h2 class="text-center my-4">📋 Records</h2>

    <!-- Filter Form -->
    <form method="GET" class="row g-3 mb-3">
        <div class="col-md-3">
            <select name="category" class="form-select">
                <option value="">-- Filter by Category --</option>
                <option value="Workshop" <?php if($filterCategory=='Workshop') echo 'selected'; ?>>Workshop</option>
                <option value="Seminar" <?php if($filterCategory=='Seminar') echo 'selected'; ?>>Seminar</option>
                <option value="Placement Drive" <?php if($filterCategory=='Placement Drive') echo 'selected'; ?>>Placement Drive</option>
                <option value="Diwali Gift" <?php if($filterCategory=='Diwali Gift') echo 'selected'; ?>>Diwali Gift</option>
            </select>
        </div>
        <div class="col-md-3">
            <input type="number" name="year" placeholder="Filter by Year" class="form-control" value="<?php echo htmlspecialchars($filterYear); ?>">
        </div>
        <div class="col-md-3">
            <input type="text" name="search" placeholder="Search any field..." class="form-control" value="<?php echo htmlspecialchars($searchTerm); ?>">
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <!-- Records Table -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Category</th>
                    <th>Title</th>
                    <th>Details</th>
                    <th>Year</th>
                    <th>Added By</th>
                    <th>Person Details</th>
                </tr>
            </thead>
            <tbody>
                <?php if($result->num_rows > 0): ?>
                    <?php
                        $sno=1;
                        while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $sno; ?></td>
                            <td><?php echo $row['category']; ?></td>
                            <td><?php echo $row['title']; ?></td>
                            <td><?php echo $row['details']; ?></td>
                            <td><?php echo $row['year']; ?></td>
                            <td><?php echo $row['addedby']; ?></td>
                            <td><?php echo $row['persondetails']; ?></td>
                        </tr>
                    <?php 
                    $sno++;    
                endwhile;
                    
                    ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center">No records found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">
        <?php for($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?php if($i==$page) echo 'active'; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>
                    <?php if($filterCategory) echo '&category='.$filterCategory; ?>
                    <?php if($filterYear) echo '&year='.$filterYear; ?>
                    <?php if($searchTerm) echo '&search='.$searchTerm; ?>">
                    <?php echo $i; ?>
                </a>
            </li>
        <?php endfor; ?>
      </ul>
    </nav>
</section>

<style>
/* .content-section {
    padding: 20px 0;
} */
.table-responsive { overflow-x: auto; }
input, select { border-radius: 8px; }
.pagination .page-item.active .page-link {
    background-color: ##0054D4;
    border-color: ##0054D4;
}
</style>

<?php
include("footer.php");
?>
