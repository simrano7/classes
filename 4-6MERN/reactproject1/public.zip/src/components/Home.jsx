function Home(){
    // JS
    var name = "Simran";
        return(
            // jsx
            <h1 id="heading1">This is Home page {name}</h1>
        )
}
export default Home;