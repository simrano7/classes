import Second from "./Second";

export default function First(){
    var a = "simran";
    return(
        <div>
            <h1>First com</h1>
            <Second data={a}/>
        </div>
    )
}


