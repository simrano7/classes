const courses = [
    {
    name:"WEB",
    duration:"6mon"
    },
    {
    name:"APP",
    duration:"6mon"
    },
    {
    name:"Cloud",
    duration:"6mon"
    },
    {
    name:"Cyber",
    duration:"6mon"
    },
]

module.exports = courses