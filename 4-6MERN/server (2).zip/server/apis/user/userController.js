const userModel = require("./userModel")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const key = "123#@12"
const login = (req,res)=>{
        var errMsgs = []
        if(!req.body.email){
                errMsgs.push("email is required!!!")
        }
        if(!req.body.password){
                errMsgs.push("password is required!!!")
        }
        if(errMsgs.length>0){
                res.send({
                    status:422,
                    success:false,
                    message:errMsgs
                })
        }
        else{
            // login logic
            userModel.findOne({email:req.body.email})
            .then((userdata)=>{
                console.log("userdata is",userdata);
                if(userdata == null){
                res.send({
                    status:404,
                    success:false,
                    message:"account not exists with this email!!"
                })

                }
                else{
                    // compare pass
                    bcrypt.compare(req.body.password,userdata.password,function(err,isMatch){
                        if(!isMatch){
                            res.send({
                                status:403,
                                success:false,
                                message:"password wrong!!"
                            })
                        }
                        else{
                            // token login success
                            let payload = {
                                _id:userdata._id,
                                name:userdata.name,
                                email:userdata.email,
                                userType:userdata.userType
                            }
                            let token  = jwt.sign(payload,key)
                            res.send({
                                status:200,
                                success:true,
                                message:"Login successfully!!",
                                token:token,
                                data:userdata
                            })    
                        }
                    })
                    
                }
                
            })
            .catch((err)=>{
                res.send({
                    status:500,
                    success:false,
                    message:"Something went wrong!!"
                })
            })
        }
}

module.exports = {login}